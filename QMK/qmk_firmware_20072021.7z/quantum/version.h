#define QMK_VERSION "9bfe0c-dirty"
#define QMK_BUILDDATE "2021-07-20-09:10:09"
#define CHIBIOS_VERSION "breaking_2020_q1-dirty"
#define CHIBIOS_CONTRIB_VERSION "breaking_2020_q1-dirty"
