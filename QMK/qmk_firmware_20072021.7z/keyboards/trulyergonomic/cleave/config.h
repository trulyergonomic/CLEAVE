/*
Copyright 2015 Álvaro "Gondolindrim" Volpato  <gondolindrim@acheronproject.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

/* USB Device descriptor parameter */
#define VENDOR_ID       0x4150
#define PRODUCT_ID      0x4152
#define DEVICE_VER      0x0001 // Revision pre-Alpha
#define MANUFACTURER    Truly Ergonomic
#define PRODUCT         Truly Ergonomic CLEAVE Keyboard

#define LED_P1   B15
#define LED_P2   C6
#define LED_P3   C7
#define LED_P4   C8
#define LED_P5   A15
#define LED_P6   C10

#define LED_N1    C0
#define LED_N2    C1
#define LED_N3    C2
#define LED_N4    C3
#define LED_N5    A0
#define LED_N6    A1
#define LED_N7    A2
#define LED_N8    A4
#define LED_N9    A5
#define LED_N10   A6
#define LED_N11   A7
#define LED_N12   C4
#define LED_N13   C5
#define LED_N14   B0
#define LED_N15   B1
#define LED_N16   B2
#define LED_N17   C11
#define LED_N18   C9
#define LED_N19   C13

#define ROW_P1   C12
#define ROW_P2   D2
#define ROW_P3   B3
#define ROW_P4   B4
#define ROW_P5   B5
#define ROW_P6   B6

#define LED_WIN   B12
#define LED_CAPS  B13
#define LED_SCR   B14

#if 0
// /* key matrix size */
// #define MATRIX_ROWS     6
// #define MATRIX_COLS     19
// #define UNUSED_PIN_NBR  10

// // #define MATRIX_COL_PINS { B0, A5, A4, A3, A2, A1, A0, F1, F0, C15, C14, C13, B9, B8}
// // #define MATRIX_ROW_PINS { B7, B6, A6, A7, B1}

// // #define MATRIX_COL_PINS { C0, C1, C2, C3, A0, A1, A2, A4, A5, A6, A7, C4, C5, B0}
// // #define MATRIX_ROW_PINS { C12, D2, B3, B3, B4} //{ C12, D2, B3, B3, B4, }

// #define MATRIX_COL_PINS { LED_N1, LED_N2, LED_N3, LED_N4, LED_N5, LED_N6, LED_N7, LED_N8, LED_N9, LED_N10, LED_N11, LED_N12, LED_N13, LED_N14, LED_N15, LED_N16, LED_N17, LED_N18, LED_N19}
// #define MATRIX_ROW_PINS { ROW_P3, ROW_P4, ROW_P3, ROW_P4, ROW_P3, ROW_P4 } //{ C12, D2, B3, B3, B4, }
// #define UNUSED_PINS { LED_P1, LED_P2, LED_P3, LED_P4, LED_P5, LED_P6, ROW_P1, ROW_P2, ROW_P5, ROW_P6 }

#else
#define MATRIX_IO_DELAY 100

/* key matrix size */
#define MATRIX_ROWS     6
#define MATRIX_COLS     19
#define UNUSED_PIN_NBR  6

#define MATRIX_COL_PINS { LED_N1, LED_N2, LED_N3, LED_N4, LED_N5, LED_N6, LED_N7, LED_N8, LED_N9, LED_N10, LED_N11, LED_N12, LED_N13, LED_N14, LED_N15, LED_N16, LED_N17, LED_N18, LED_N19 }
#define MATRIX_ROW_PINS { ROW_P1, ROW_P2, ROW_P3, ROW_P4, ROW_P5, ROW_P6} //{ C12, D2, B3, B3, B4, }
#define UNUSED_PINS { LED_P1, LED_P2, LED_P3, LED_P4, LED_P5, LED_P6 }

// #define BACKLIGHT_PINS UNUSED_PINS

#endif
#define DIODE_DIRECTION CLEAVE_TYPE //COL2ROW

// #define BACKLIGHT_PIN           A6
// #define BACKLIGHT_PWM_DRIVER    PWMD3
// #define BACKLIGHT_PWM_CHANNEL   1
// #define BACKLIGHT_PAL_MODE      1
// #define BACKLIGHT_LEVELS 6
// #define BACKLIGHT_BREATHING
// #define BREATHING_PERIOD 6

/* define if matrix has ghost */
//#define MATRIX_HAS_GHOST

/* Set 0 if debouncing isn't needed */
#define DEBOUNCE    5

/* Mechanical locking support. Use KC_LCAP, KC_LNUM or KC_LSCR instead in keymap */
#define LOCKING_SUPPORT_ENABLE
/* Locking resynchronize hack */
#define LOCKING_RESYNC_ENABLE

/*
 * Feature disable options
 *  These options are also useful to firmware size reduction.
 */

/* disable debug print */
//#define NO_DEBUG

/* disable print */
//#define NO_PRINT

/* disable action features */
//#define NO_ACTION_LAYER
//#define NO_ACTION_TAPPING
//#define NO_ACTION_ONESHOT
//#define NO_ACTION_MACRO
//#define NO_ACTION_FUNCTION


