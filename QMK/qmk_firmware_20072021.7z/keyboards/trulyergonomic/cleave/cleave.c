/*
Copyright 2015 Álvaro "Gondolindrim" Volpato  <gondolindrim@acheronproject.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "cleave.h"
#include "config.h"

#ifdef _X_
    #undef _X_
#endif
#define _X_ 1

#ifdef ___
    #undef ___
#endif
#define ___ 0

static const pin_t row_pins[MATRIX_ROWS] = MATRIX_ROW_PINS;
static const pin_t col_pins[MATRIX_COLS] = MATRIX_COL_PINS;
#ifdef UNUSED_PINS
static const pin_t unused_pins[UNUSED_PIN_NBR] = UNUSED_PINS;
#endif


typedef uint8_t matrix_led_buffer_t[MATRIX_ROWS][MATRIX_COLS];

/*
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
    | ESC  | ___  | F1   | F2   | F3   | F4  | F5   | F6   | F7   | F8   | F9   | F10  | F11 | F12  | DEL  | ___  | CAP | Fn  | WIN |
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
    | BTAB | `    | 1    | 2    | 3    | 4   | 5    | COPY | UNDO | 6    | 7    | 8    | 9   | 0    | -    | =    | ___ | ___ | ___ |
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
    | TAB  | TAB  | Q    | W    | E    | R   | T    | CUT  | PST  | Y    | U    | I    | O   | P    | [    | ]    | ___ | ___ | ___ |
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
    | LCTL | LCTL | A    | S    | D    | F   | G    | DEL  | BKSP | H    | J    | K    | L   | ;    | '    | \    | ___ | ___ | ___ |
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
    | LSHT | LSHT | Z    | X    | C    | V   | B    | DEL  | BKSP | N    | M    | ,    | .   | /    | RSHT | RSHT | ___ | ___ | ___ |
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
    | LCTL | LALT | HOME | PGUP | PGDN | END | LSPC | LSHT | ENT  | RSPC | LEFT | DOWN | UP  | RGHT | RALT | RCTL | ___ | ___ | ___ |
    +------+------+------+------+------+-----+------+------+------+------+------+------+-----+------+------+------+-----+-----+-----+
 */
static const matrix_led_buffer_t fn0_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn1_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn2_led_matrix_buffer = {
    {_X_,   ___,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn3_led_matrix_buffer = {
    {_X_,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn4_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn5_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn6_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn7_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___},
    {___,   ___,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn8_led_matrix_buffer = {
    {___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   ___,   ___,   ___}
};
static const matrix_led_buffer_t fn9_led_matrix_buffer = {
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_},
    {_X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_,   _X_}
};

matrix_led_buffer_t *led_buffer_ptr = (matrix_led_buffer_t*)&fn9_led_matrix_buffer;
uint32_t highest_layer = 0;
uint32_t layer_to_be_changed = 0;

void matrix_io_delay(void)
{
    chThdSleepMicroseconds(500);
}

void matrix_io_delay_us(uint32_t us)
{
    chThdSleepMicroseconds(us);
}

void led_set_user(uint8_t usb_led) {
    // Caps Lock Indicator
    if (IS_HOST_LED_ON(USB_LED_CAPS_LOCK)) {
        writePinHigh(LED_CAPS);
    } else if (IS_HOST_LED_OFF(USB_LED_CAPS_LOCK)) {
        writePinLow(LED_CAPS);
    }
    /* Scroll Lock Indicator */
    if (IS_HOST_LED_ON(USB_LED_SCROLL_LOCK)) {
        writePinHigh(LED_SCR);
    } else if (IS_HOST_LED_OFF(USB_LED_SCROLL_LOCK)) {
        writePinLow(LED_SCR);
    }

    highest_layer = get_highest_layer(layer_state);

    /* Save the index of the layer to be updated */
    if(highest_layer < 4) {
        layer_to_be_changed = highest_layer;
    }
    // // Layer Indicator
    // else {
    //     switch (get_highest_layer(layer_state)) {
    //         // Fn Layer Indicator
    //         case _FN:
    //             rgblight_mode_noeeprom(RGBLIGHT_MODE_STATIC_GRADIENT + 1);
    //             break;
    //         // Default Layer Indicator
    //         case _BASE:
    //             rgblight_setrgb(100, 255, 100);
    //             break;
    //     }
    //     update_led();
    // }
}

void matrix_setup(void)
{

    /* set LED pin as output */
    setPinOutput(LED_WIN);
    setPinOutput(LED_CAPS);
    setPinOutput(LED_SCR);
    setPinOutput(ROW_P2);


    writePinLow(LED_WIN);
    writePinLow(LED_CAPS);
    writePinLow(LED_SCR);
    writePinLow(ROW_P2);

    for (uint8_t x = 0; x < MATRIX_ROWS; x++) {
        setPinOutput(row_pins[x]);
        writePinLow(row_pins[x]);
    }

    for (uint8_t x = 0; x < MATRIX_COLS; x++) {
        setPinInput(col_pins[x]);
    }
#ifdef UNUSED_PINS
    for (uint8_t x = 0; x < UNUSED_PIN_NBR; x++) {
        setPinOutput(unused_pins[x]);
        writePinHigh(unused_pins[x]);
    }
#endif
}

static void setup_matrix_led_pins(void)
{
    /* Keypad row control, active HIGH */
    for (uint8_t x = 0; x < MATRIX_ROWS; x++) {
        setPinOutput(row_pins[x]);
        writePinLow(row_pins[x]);
    }

    /* Led columns control pins, active HIGH */
    for (uint8_t x = 0; x < MATRIX_COLS; x++) {
        setPinOutput(col_pins[x]);
        writePinLow(col_pins[x]);
    }

    /* Led row control pins, active: HIGH */
#ifdef UNUSED_PINS
    for (uint8_t x = 0; x < UNUSED_PIN_NBR; x++) {
        setPinOutput(unused_pins[x]);
        writePinLow(unused_pins[x]);
    }
#endif
}

static void select_led_row(uint8_t row) {
    writePinHigh(unused_pins[row]);
}

static void unselect_led_row(uint8_t row) {
    writePinLow(unused_pins[row]);

    for (uint8_t x = 0; x < MATRIX_COLS; x++) {
        writePinLow(col_pins[x]);
    }
}

static void matrix_scan_backlight_led(matrix_led_buffer_t buffer) {
    for (uint8_t x = 0; x < MATRIX_ROWS; x++) {
        select_led_row(x);
        for (uint8_t y = 0; y < MATRIX_COLS; y++) {
            if (buffer[x][y] == _X_) {
                writePinHigh(col_pins[y]);
            }
        }
        matrix_io_delay_us(500);
        unselect_led_row(x);
    }
}

void matrix_scan_kb(void) {

    setup_matrix_led_pins();
    matrix_scan_backlight_led(*led_buffer_ptr);
}

bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
  switch (keycode) {
    case LED_F0:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn0_led_matrix_buffer;
        return false;
    case LED_F1:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn1_led_matrix_buffer;
        return false;
    case LED_F2:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn2_led_matrix_buffer;
        return false;
    case LED_F3:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn3_led_matrix_buffer;
        return false;
    case LED_F4:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn4_led_matrix_buffer;
        return false;
    case LED_F5:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn5_led_matrix_buffer;
        return false;
    case LED_F6:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn6_led_matrix_buffer;
        return false;
    case LED_F7:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn7_led_matrix_buffer;
        return false;
    case LED_F8:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn8_led_matrix_buffer;
        return false;
    case LED_F9:
        led_buffer_ptr = (matrix_led_buffer_t*)&fn9_led_matrix_buffer;
        return false;

    /* Process Fn + Esc + Y, U, P */

    /* Fn + Esc + Y */
    case FN_ESC_Y:
        /* Set Secondary_LEFT_Upper_Ctrl to Esc for all normal layer (1-3) */
        for (uint8_t i = 0; i < 3; i ++) {
            keymaps[i][3][0] = KC_ESC;
        }
        return false;

    /* Fn + Esc + U */
    case FN_ESC_U:
        /* Set Secondary_LEFT_Upper_Ctrl to Left_Ctrl (Default) for all normal layer (1-3) */
        for (uint8_t i = 0; i < 3; i ++) {
            keymaps[i][3][0] = KC_LCTL;
        }
        return false;

    /* Fn + Esc + I */
    case FN_ESC_I:
        /* Set Secondary_LEFT_Upper_Ctrl to Left_Windows_key for all normal layer (1-3) */
        for (uint8_t i = 0; i < 3; i ++) {
            keymaps[i][3][0] = KC_LWIN;
        }
        return false;

    /* Fn + Esc + O */
    case FN_ESC_O:
        /* Set Secondary_LEFT_Upper_Ctrl to CapsLock for all normal layer (1-3) */
        for (uint8_t i = 0; i < 3; i ++) {
            keymaps[i][3][0] = KC_CAPS;
        }
        return false;

    /* Fn + Esc + P */
    case FN_ESC_P:
        /* Set Secondary_LEFT_Upper_Ctrl to F24 for all normal layer (1-3) */
        for (uint8_t i = 0; i < 3; i ++) {
            keymaps[i][3][0] = KC_F24;
        }
        return false;

    /* Fn + Esc + secondary_LEFT_Space */
    case FN_ESC_SLSPC:

        return false;

    /* Fn + Esc + secondary_LEFT_Shift */
    case FN_ESC_SLSFT:

        return false;

    /* Fn + Esc + secondary_Delete */
    case FN_ESC_SDEL:

        return false;

    /* Fn + Esc + Backspace */
    case FN_ESC_BSPC:

        return false;

    /* Fn + Esc + Enter */
    case FN_ESC_ENT:

        return false;

    /* Fn + Esc + RIGHT_Space */
    case FN_ESC_RSPC:

        return false;

    default:
        break;
  }

  return process_record_user(keycode, record);
}
